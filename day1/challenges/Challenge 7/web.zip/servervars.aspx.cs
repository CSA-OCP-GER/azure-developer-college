using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class servervars : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        IEnumerator myenum = System.Web.HttpContext.Current.Request.ServerVariables.AllKeys.GetEnumerator();

        if (Environment.MachineName.Contains("red"))
        {
            pageBody.Attributes.Add("bgcolor", "red");
        }
        else if (Environment.MachineName.Contains("blue"))
        {
            pageBody.Attributes.Add("bgcolor", "blue");
        }
        string finalstring = "<p><h1><b>You are being served by: " + Environment.MachineName + "</b></h1></p>";

        finalstring += "<table border=1>";

        while (myenum.MoveNext())
        {
            finalstring += "<tr><td><b>" + myenum.Current.ToString() + "</b></td><td>" + System.Web.HttpContext.Current.Request.ServerVariables.Get(myenum.Current.ToString()) + "</td></tr>";
        }
        finalstring += "</table>";
        Label1.Text = finalstring;
    }
}
