using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class servervars : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        IEnumerator myenum = System.Web.HttpContext.Current.Request.ServerVariables.AllKeys.GetEnumerator();
        string finalstring = "<table border=1>";

        while (myenum.MoveNext())
        {
            finalstring += "<tr><td><b>" + myenum.Current.ToString() + "</b></td><td>" +  System.Web.HttpContext.Current.Request.ServerVariables.Get(myenum.Current.ToString()) + "</td></tr>";
        }
        finalstring += "</table>";
        Label1.Text = finalstring;
    }
}
